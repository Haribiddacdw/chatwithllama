from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from huggingface_hub import login
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, pipeline
from langchain_community.llms import HuggingFacePipeline
from langchain.chains import ConversationalRetrievalChain, RetrievalQA
from langchain.memory import ConversationBufferMemory
from langchain_community.vectorstores import FAISS
from langchain.prompts import PromptTemplate
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import torch
import transformers
import os
import sys
from flask import Flask,request, jsonify
from pyngrok import ngrok
import re
import json
port_no = 5000

hftoken="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"
model_id = "meta-llama/Llama-2-7b-chat-hf"
ngrok_token = "2cRbFPFIaHkwElZ7cboi7PXPE0z_i9qAzp2GaNytbcVmjQ4T"
DB_FAISS_PATH = 'vectorstore/db_faiss'


os.environ["TOKENIZERS_PARALLELISM"] = "false"

def login_to_huggingface():
  hf_token = hftoken
  login(token=hf_token, add_to_git_credential=False)

def create_vector_db_from_document(pdf_path):
    document = []
    loader = PyPDFLoader(pdf_path)
    document.extend(loader.load())

    document_splitter = CharacterTextSplitter(separator='\n', chunk_size=500, chunk_overlap=100)
    document_chunks = document_splitter.split_documents(document)

    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2',model_kwargs={'device': 'cpu'})

    vectors = FAISS.from_documents(document_chunks, embeddings)
    vectors.save_local(DB_FAISS_PATH)
    return vectors

def setup_model():
    login_to_huggingface()
    quantization_config = BitsAndBytesConfig(load_in_4bit=True)
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id,device_map='mps',torch_dtype=torch.float16,config=quantization_config)
    pipe=pipeline("text-generation",
            model=model,
            tokenizer=tokenizer,
            torch_dtype=torch.bfloat16,
            device_map='mps',
            max_new_tokens=512,
            min_new_tokens=-1,
            top_k=30
            )
    llm = HuggingFacePipeline(pipeline=pipe, model_kwargs={'temperature':0})
    return llm


def conversation_retrieval_QA_Chain(llm,db):
    global qa_chain
    template = """Use the following pieces of context to answer the question at the end. If you don't know the answer, just say that you don't know, don't try to make up an answer. and also don't answer for harmful, offensive questions. Use three sentences maximum. Keep the answer as concise as possible. Always say "thanks for asking!" at the end of the answer.
    {context}
    Question: {question}
    Helpful Answer:"""
    PROMPT = PromptTemplate(
    template=template, input_variables=["context", "question"]
    )
    qa_chain = RetrievalQA.from_chain_type(
        llm,
        retriever=db.as_retriever(search_kwargs={'k':4}),
        return_source_documents=True,
        chain_type_kwargs={"prompt": PROMPT}
    )
    return qa_chain


def get_response_from_llm(question, qa_chain):
    sentence_transformer_model = SentenceTransformer('all-MiniLM-L6-v2')
    THRESHOLD = 0.5

    result = qa_chain({"query": question})
    docs_page_content = " ".join([d.page_content for d in result["source_documents"]])

    question_emb = sentence_transformer_model.encode(question)
    context_emb = sentence_transformer_model.encode(docs_page_content)

    if len(question_emb.shape) == 1:
        question_emb = question_emb.reshape(1, -1)

    if len(context_emb.shape) == 1:
        context_emb = context_emb.reshape(1, -1)
    similarity_score = cosine_similarity(question_emb, context_emb)

    if similarity_score < THRESHOLD:
        return "Sorry I don't know !"
    else:
        return result["result"]

def setup_flask_app(port_no):
    app = Flask(__name__)
    ngrok.set_auth_token(ngrok_token)
    public_url =  ngrok.connect(port_no).public_url

    @app.route("/")
    def home():
        return f"Running Flask on Google Colab!"

    @app.route('/getResponse', methods=['POST'])
    def llm_response():
        try:
            query = request.json
            if not query or 'question' not in query:
                return jsonify({"error": "Invalid or missing 'question' parameter in JSON body"}), 400

            response = get_response_from_llm(query["question"], qa_chain)
            answer_lines = re.split(r"\n\n?", response)
            return jsonify({"answer": answer_lines})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    print(f"To access the Global link please click {public_url}")
    return app

def main():
    pdf_path = "./src/data/website_data_utah.pdf"                    
    db = create_vector_db_from_document(pdf_path)
    llm = setup_model()
    conversation_retrieval_QA_Chain(llm,db) 
    app = setup_flask_app(5000)
    app.run(port=5000)

if __name__ == "__main__":
    main()
